# Chat Bot

Converse with SpOC's AI/ML chat bot!
Input your question or comment to start a conversation.
SpOC Chat Bot uses OpenAI's ChatGPT language model to provide responses.

## Setup

Use Python 3.7.5.

1. Navigate to the project directory: `cd <path to chat_bot>`
2. Create a new virtual environment: `python -m venv <virtual environment name>`
3. Activate the virtual environment:
    - bash: `source <virtual environment name>/bin/activate`
    - Git Bash: `source <virtual environment name>/Scripts/activate`
    - cmd.exe: `<virtual environment name>\Scripts\activate.bat`
    - PowerShell: `<virtual environment name>\Scripts\Activate.ps1`
4. Upgrade pip: `pip install --upgrade pip`
5. Install the necessary packages: `pip install -r requirements.txt`
6. Create a `.credentials` file in the base of repository
7. Add an OpenAI API key to the file

## Operation

1. Run web app: `python -m chat_bot_dash.app`
