import dash
from dash.dependencies import Input, Output, State
import dash_bootstrap_components as dbc
import openai

import chat_bot_dash.utilities as utilities


openai.api_key = utilities.read_credentials()
path = utilities.get_project_path().resolve().parent.joinpath('chat_bot')

app = dash.Dash(__name__, suppress_callback_exceptions=True)
server = app.server  # expose server variable for Procfile
app.layout = utilities.create_layout()


@app.callback(Output('text_conversation', 'children'), [Input('store_conversation', 'data')])
def update_display(chat_history):
    return [
        textbox(x, box='other') if i % 2 == 0 else textbox(x, box='self')
        for i, x in enumerate(chat_history.split(';')[:-1])
    ]


@app.callback(
    [Output('store_conversation', 'data'), Output('text_input', 'value')],
    [Input('button_submit', 'n_clicks')],
    [State('text_input', 'value'), State('store_conversation', 'data')],
)
def run_chatbot(n_clicks, user_input, chat_history):
    if n_clicks == 0:
        return '', ''
    if user_input is None or user_input == '':
        return chat_history, ''
    chat_history += f"{user_input};"
    chat_history += f"{get_response(user_input)};"
    return chat_history, ''


app.clientside_callback(
    """
    function(text) {
        var objDiv = document.getElementById("text_conversation");
        objDiv.scrollTop = objDiv.scrollHeight;
    }
    """,
    Output('placeholder', 'children'),
    Input('text_conversation', 'children')
)


def textbox(text: str, box: str='other') -> dbc.Card:
    style = {
        'max-width': '75%', 'width': 'max-content', 'padding': '10px 15px', 'border-radius': '25px', 'margin-top': '10px',
        'border-width': '5px', 'border-color': '#862633', 'border-style': 'solid', 'background-clip': 'padding-box'}
    if box == 'self':
        box_style = {'margin-left': 'auto', 'margin-right': '20px', 'background-color': '#00263A', 'color': '#DBE2E9'}
    elif box == 'other':
        box_style = {'margin-left': '20px', 'margin-right': 'auto', 'background-color': '#DBE2E9', 'color': '#00263A'}
    return dbc.Card(text, style={**style, **box_style}, body=True)


def get_response(user_input: str) -> str:
    try:
        response = openai.Completion.create(engine='text-davinci-003', prompt=user_input, max_tokens=100)
        if 'choices' in response:
            first_choice = response.choices[0].text.rsplit('.', 1)[0]
            return f"{first_choice}."
        return "Sorry, I do not understand. Please try again."
    except:
        return "An error occurred while obtaining a response. Please try again."
    

if __name__ == '__main__':
    app.run_server(host='0.0.0.0', debug=True, port=8050)
