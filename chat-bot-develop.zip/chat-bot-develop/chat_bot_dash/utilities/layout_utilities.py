from dash import dcc, html
import dash_bootstrap_components as dbc

import chat_bot_dash.utilities as utilities


def create_layout() -> html.Div:
    return html.Div(children=[html.Div(className='row', children=[
        create_information_layout(), create_data_layout()])])


def create_information_layout() -> html.Div:
    return html.Div(className='three columns div-user-controls', children=[
        create_title(), create_description(), create_logo(), create_placeholder()])


def create_data_layout() -> html.Div:
    return html.Div(className='nine columns div-for-charts bg-grey', children=[
        html.Div(style={'height': '100%', 'width': '100%'}), create_chat(), create_contact_information()],
        style={'textAlign': 'center', 'align-items': 'center'})


def create_title() -> html.H1:
    return html.H1("SpOC Chat Bot")


def create_description() -> html.P:
    return html.P((f"Converse with SpOC's AI/ML chat bot! Input your question or comment to start a conversation." 
                    f" SpOC Chat Bot uses OpenAI's ChatGPT language model to provide responses."
                    f"\n\nWarning: Do not add sensitive information to the chat."), style={'whiteSpace': 'pre-wrap'})


def create_logo() -> html.Div:
    return html.Div(className='logo', children=[
        utilities.encode_image(path=utilities.get_project_path().joinpath('assets', 'spoc_logo.png'))])


def create_placeholder() -> html.Div:
    return html.Div(id='placeholder', style={'display': 'none'})


def create_chat() -> html.Div:
    return html.Div(className='nine columns div-for-charts bg-grey', children=[
        dcc.Store(id='store_conversation', data=''), create_conversation(), create_controls()
    ], style={'display': 'flex', 'justify-content': 'center', 'align-items': 'center', 'margin': '0'})


def create_conversation() -> html.Div:
    return html.Div(className='nine columns div-for-charts bg-grey', id='text_conversation',
        style={'width': '100%', 'height': '100%', 'overflow-y': 'auto', 'color': '#00263A', 'margin-top': '20px'})


def create_controls() -> dbc.InputGroup:
    return dbc.InputGroup(className='nine columns div-for-charts bg-grey',
        style={'width': '100%', 'margin': '0', 'display': 'flex', 'justify-content': 'center', 'align-items': 'center'},
        children=[
            dbc.Input(id='text_input', placeholder="Input text...", type='text',
                style={'border-style': 'solid', 'border-color': '#862633', 'border-width': '5px', 'background-color': '#DBE2E9', 'color': '#00263A', 'width': '80%'}),
            dbc.Button("Submit", id='button_submit', style={'background-color': '#00263A', 'color': '#DBE2E9'})
        ]
    )


def create_contact_information() -> html.Footer:
    return html.Footer(className='footer', children="jeffrey.williams.51@spaceforce.mil, alexis.denhard.ctr@spaceforce.mil, benjamin.johnson.90.ctr@spaceforce.mil")
